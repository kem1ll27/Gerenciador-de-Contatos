# Gerenciador de Contatos - PHP + MySQLi

Sistema simples de cadastro e consulta de contatos com proteção total contra SQL Injection.

## Como rodar

1. Coloque a pasta `gerenciador-contatos` dentro da pasta `www` ou `htdocs`.
2. Ajuste a senha do MySQL no início do `index.php` se necessário (geralmente está vazia).
3. Acesse: **http://localhost/gerenciador-contatos/**

**O sistema cria o banco e a tabela automaticamente** na primeira vez que você abrir a página.  
Não precisa rodar o script.sql.

## Segurança

- Usa **Prepared Statements** (mysqli OO)
- Nenhum dado do usuário é concatenado diretamente na SQL
- `htmlspecialchars()` na saída para prevenir XSS
- Verificação de erro de conexão com `$mysqli->connect_errno`

## Funcionalidades

- Cadastro de contatos (nome + descrição) via POST
- Listagem de todos os contatos
- Filtro dinâmico com LIKE `%termo%`
- Interface limpa e responsiva
