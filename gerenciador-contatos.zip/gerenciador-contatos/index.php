<?php
// ============================================
// Gerenciador de Contatos - PHP + MySQLi (OO)
// Protegido contra SQL Injection
// ============================================

// Configuração do banco
$host = 'localhost';
$user = 'root';
$pass = ''; // Ajuste a senha se necessário
$db   = 'contatos_db';

// 1. Conecta SEM selecionar o banco (para poder criá-lo)
$mysqli = new mysqli($host, $user, $pass);

// Verifica erro de conexão
if ($mysqli->connect_errno) {
    die("Falha na conexão: (" . $mysqli->connect_errno . ") " . $mysqli->connect_error);
}

// 2. Cria o banco de dados se não existir
$mysqli->query("CREATE DATABASE IF NOT EXISTS `$db` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");

// 3. Seleciona o banco
$mysqli->select_db($db);

// 4. Cria a tabela se não existir
$mysqli->query("
    CREATE TABLE IF NOT EXISTS contatos (
        id INT AUTO_INCREMENT PRIMARY KEY,
        nome VARCHAR(100) NOT NULL,
        descricao TEXT,
        criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
");

// Define charset
$mysqli->set_charset("utf8mb4");

// ============================================
// CADASTRO (POST)
// ============================================
$mensagem = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['acao']) && $_POST['acao'] === 'cadastrar') {
    
    $nome = trim($_POST['nome'] ?? '');
    $descricao = trim($_POST['descricao'] ?? '');

    if (!empty($nome)) {
        // Prepared Statement (seguro contra SQL Injection)
        $stmt = $mysqli->prepare("INSERT INTO contatos (nome, descricao) VALUES (?, ?)");
        $stmt->bind_param("ss", $nome, $descricao);
        
        if ($stmt->execute()) {
            $mensagem = "Contato cadastrado com sucesso!";
        } else {
            $mensagem = "Erro ao cadastrar: " . $stmt->error;
        }
        $stmt->close();
    } else {
        $mensagem = "O nome é obrigatório.";
    }
}

// ============================================
// BUSCA / FILTRO (GET ou POST)
// ============================================
$termo = '';
$resultados = [];

if (isset($_GET['busca']) || isset($_POST['busca'])) {
    $termo = trim($_GET['busca'] ?? $_POST['busca'] ?? '');
}

if (!empty($termo)) {
    // Prepared Statement com LIKE (seguro)
    $like = "%" . $termo . "%";
    $stmt = $mysqli->prepare("SELECT id, nome, descricao, criado_em FROM contatos WHERE nome LIKE ? OR descricao LIKE ? ORDER BY id DESC");
    $stmt->bind_param("ss", $like, $like);
    $stmt->execute();
    $result = $stmt->get_result();
    
    while ($row = $result->fetch_assoc()) {
        $resultados[] = $row;
    }
    $stmt->close();
} else {
    // Lista todos se não houver busca
    $result = $mysqli->query("SELECT id, nome, descricao, criado_em FROM contatos ORDER BY id DESC");
    while ($row = $result->fetch_assoc()) {
        $resultados[] = $row;
    }
}

$mysqli->close();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerenciador de Contatos</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body {
            font-family: system-ui, -apple-system, sans-serif;
            background: #f1f5f9;
            color: #1e293b;
            line-height: 1.5;
            padding: 20px;
        }
        .container {
            max-width: 900px;
            margin: 0 auto;
        }
        h1 {
            text-align: center;
            margin-bottom: 30px;
            color: #0f172a;
        }
        .card {
            background: white;
            border-radius: 10px;
            padding: 25px;
            margin-bottom: 25px;
            box-shadow: 0 4px 6px -1px rgb(0 0 0 / 0.1);
        }
        h2 {
            margin-bottom: 20px;
            font-size: 1.3rem;
            color: #334155;
        }
        label {
            display: block;
            margin-bottom: 6px;
            font-weight: 600;
            font-size: 0.95rem;
        }
        input[type="text"],
        textarea {
            width: 100%;
            padding: 12px 14px;
            border: 2px solid #e2e8f0;
            border-radius: 8px;
            font-size: 1rem;
            margin-bottom: 15px;
            transition: border-color 0.2s;
        }
        input[type="text"]:focus,
        textarea:focus {
            outline: none;
            border-color: #3b82f6;
        }
        textarea {
            min-height: 80px;
            resize: vertical;
        }
        button {
            background: #3b82f6;
            color: white;
            border: none;
            padding: 12px 24px;
            border-radius: 8px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: background 0.2s;
        }
        button:hover {
            background: #2563eb;
        }
        .mensagem {
            padding: 12px 16px;
            border-radius: 8px;
            margin-bottom: 20px;
            background: #dcfce7;
            color: #166534;
            border: 1px solid #bbf7d0;
        }
        .busca-form {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
        }
        .busca-form input {
            flex: 1;
            margin-bottom: 0;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 12px 14px;
            text-align: left;
            border-bottom: 1px solid #e2e8f0;
        }
        th {
            background: #f8fafc;
            font-weight: 600;
            color: #475569;
        }
        tr:hover {
            background: #f8fafc;
        }
        .vazio {
            text-align: center;
            padding: 30px;
            color: #64748b;
            font-style: italic;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Gerenciador de Contatos</h1>

        <!-- Formulário de Cadastro -->
        <div class="card">
            <h2>Cadastrar Contato</h2>

            <?php if ($mensagem): ?>
                <div class="mensagem"><?= htmlspecialchars($mensagem) ?></div>
            <?php endif; ?>

            <form method="POST" action="">
                <input type="hidden" name="acao" value="cadastrar">

                <label for="nome">Nome</label>
                <input type="text" id="nome" name="nome" required placeholder="Ex: João Silva">

                <label for="descricao">Descrição</label>
                <textarea id="descricao" name="descricao" placeholder="Ex: Amigo da faculdade, telefone..."></textarea>

                <button type="submit">Cadastrar</button>
            </form>
        </div>

        <!-- Painel de Consulta com Filtro -->
        <div class="card">
            <h2>Consultar Contatos</h2>

            <form method="GET" action="" class="busca-form">
                <label for="busca" style="display:none;">Buscar</label>
                <input type="text" id="busca" name="busca" value="<?= htmlspecialchars($termo) ?>" placeholder="Digite um termo para filtrar...">
                <button type="submit">Buscar</button>
            </form>

            <?php if (empty($resultados)): ?>
                <p class="vazio">Nenhum resultado encontrado.</p>
            <?php else: ?>
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nome</th>
                            <th>Descrição</th>
                            <th>Data</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($resultados as $contato): ?>
                            <tr>
                                <td><?= (int)$contato['id'] ?></td>
                                <td><?= htmlspecialchars($contato['nome']) ?></td>
                                <td><?= htmlspecialchars($contato['descricao'] ?? '') ?></td>
                                <td><?= htmlspecialchars($contato['criado_em']) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
