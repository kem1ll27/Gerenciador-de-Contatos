# Gerenciador de Contatos - PHP + MySQLi

Sistema completo de cadastro, consulta, edição e exclusão de contatos com proteção total contra SQL Injection.

## Como rodar

1. Coloque a pasta `gerenciador-contatos` dentro da pasta `www` ou `htdocs`.
2. Ajuste a senha do MySQL no início do `index.php` se necessário (geralmente está vazia).
3. Acesse: **http://localhost/gerenciador-contatos/**

**O sistema cria o banco e a tabela automaticamente** na primeira vez que você abrir a página.

## Funcionalidades (CRUD completo)

- **Create** → Cadastrar contato
- **Read** → Listar + Filtrar com LIKE
- **Update** → Editar contato (botão amarelo)
- **Delete** → Deletar contato (botão vermelho + confirmação)

## Segurança

- Usa **Prepared Statements** em todas as operações
- Nenhum dado do usuário é concatenado diretamente na SQL
- `htmlspecialchars()` na saída para prevenir XSS
- Verificação de erro de conexão com `$mysqli->connect_errno`
